// *****************************************************************************
// Module..: SerialDemo -- Software development kit for Leddar products. Sensor
//           communication demonstration program.
//
/// \file    Main.c
///
/// \brief   This is the main file containing the menu driver.
///
// Copyright (c) 2014 LeddarTech Inc. All rights reserved.
// Information contained herein is or may be confidential and proprietary to
// LeddarTech inc. Prior to using any part of the software development kit
// accompanying this notice, you must accept and agree to be bound to the
// terms of the LeddarTech Inc. license agreement accompanying this file.
// *****************************************************************************

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#include "Leddar.h"

// Mapping between the value in the baud rate register and the real baud rate
// value
static int gBAUDS[] =
{
    115200, 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600
};

// *****************************************************************************
// Function: GetMenuChoice
//
/// \brief   Loops until a key is entered that is valid in a menu.
///
/// \return  The key entered.
// *****************************************************************************

static int
GetMenuChoice( void )
{
    int lResult = 0;

    while( ( lResult < '1' ) || ( lResult > '9' ) )
    {
        lResult = toupper( GetKey() );

        if ( lResult == 'Q' )
        {
            break;
        }
    }

    return lResult;
}

// *****************************************************************************
// Function: DisplayDetections
//
/// \brief   Display detection as well as other information in a continuous
///          loop until the user presses a key.
// *****************************************************************************

static void
DisplayDetections( void )
{
    LtAcquisition lAcquisition;

    puts( "\nPress a key to start and then press a key again to stop." );
    GetKey();

    while( !KeyPressed() )
    {
        if ( LeddarGetResults( &lAcquisition ) == LT_SUCCESS )
        {
            int i;
            LtDetection *lDetections = lAcquisition.mDetections;

            printf( "\nTimestamp    : %d\n", lAcquisition.mTimestamp );
            {
                printf( "Temperature  : %.1f deg C\n", lAcquisition.mTemperature );
            }

            for( i=0; i<lAcquisition.mDetectionCount; ++i )
            {
                printf( "%7.3f %6.2f    ",
                        lDetections[i].mDistance, lDetections[i].mAmplitude );
            }

            puts( "" );
        }
        else
        {
            puts( "Communication error, aborting." );
            break;
        }
    }

    // Absorb the key used to stop the loop.
    GetKey();
}

// *****************************************************************************
// Function: DisplayConfiguration
//
/// \brief   Display the current configuration parameters. What is displayed
///          is adapted for the type or sensor (assumed not called when
///          sensor does not support configuration).
// *****************************************************************************

static void
DisplayConfiguration( void )
{
#define DC_COMM_ERROR "Communication Error!"

    LtU16 lValue;

    puts( "" );

    printf( "Accumulation           : " );
    if ( LeddarGetParameter( LEDDAR_CONFIG_ACCUMULATION, &lValue ) == LT_SUCCESS )
    {
        printf( "%d (%d)\n", lValue, 1<<lValue );
    }
    else
    {
        puts( DC_COMM_ERROR );
    }

    printf( "Oversampling           : " );
    if ( LeddarGetParameter( LEDDAR_CONFIG_OVERSAMPLING, &lValue ) == LT_SUCCESS )
    {
        printf( "%d (%d)\n", lValue, 1<<lValue );
    }
    else
    {
        puts( DC_COMM_ERROR );
    }

    printf( "Base sample count      : " );
    if ( LeddarGetParameter( LEDDAR_CONFIG_SAMPLE_COUNT, &lValue ) == LT_SUCCESS )
    {
        printf( "%d\n", lValue );
    }
    else
    {
        puts( DC_COMM_ERROR );
    }

    printf( "LED power              : " );
    if ( LeddarGetParameter( LEDDAR_CONFIG_LED_POWER, &lValue ) == LT_SUCCESS )
    {
        printf( "%d%%\n", lValue );
    }
    else
    {
        puts( DC_COMM_ERROR );
    }

    printf( "Baud Rate              : " );
    if ( LeddarGetParameter( LEDDAR_CONFIG_BAUD_RATE, &lValue ) == LT_SUCCESS )
    {
        if ( lValue < sizeof(gBAUDS)/sizeof(gBAUDS[0]) )
        {
            printf( "%d%\n", gBAUDS[lValue] );
        }
        else
        {
            puts( "??" );
        }
    }
    else
    {
        puts( DC_COMM_ERROR );
    }

    printf( "Modbus Address         : " );
    if ( LeddarGetParameter( LEDDAR_CONFIG_MODBUS_ADDRESS, &lValue ) == LT_SUCCESS )
    {
        printf( "%d%\n", lValue );
    }
    else
    {
        puts( DC_COMM_ERROR );
    }
}

// *****************************************************************************
// Function: ConfigurationMenu
//
/// \brief   Display a menu to allow changing configuration parameters.
// *****************************************************************************

static void
ConfigurationMenu( void )
{
    for(;;)
    {
        int      lChoice;
        float    lValue;
        LtResult lResult;

        puts( "\n" );
        puts( "1. Change accumulation" );
        puts( "2. Change oversampling" );
        puts( "3. Change base sample count" );
        puts( "4. Change LED power" );
        // Note that for a change to the baud rate or Modbus address to take
        // effect, the sensor must be restarted.
        puts( "5. Change baud rate" );
        puts( "6. Change modbus address" );
        puts( "8. Write to permanent memory" );
        puts( "9. Exit" );

        lChoice = GetMenuChoice();

        if ( lChoice == '9' )
        {
            break;
        }

        if ( lChoice != '8' )
        {
            printf( "\nEnter new value: " );
            scanf( "%f", &lValue );
        }

        switch( lChoice )
        {
            case '1':
                lResult = LeddarSetParameter( LEDDAR_CONFIG_ACCUMULATION, (LtU16) lValue );
                break;
            case '2':
                lResult = LeddarSetParameter( LEDDAR_CONFIG_OVERSAMPLING, (LtU16) lValue );
                break;
            case '3':
                lResult = LeddarSetParameter( LEDDAR_CONFIG_SAMPLE_COUNT, (LtU16) lValue );
                break;
            case '4':
                lResult = LeddarSetParameter( LEDDAR_CONFIG_LED_POWER, (LtU16) lValue );
                break;
            case '5':
                lResult = LeddarSetParameter( LEDDAR_CONFIG_BAUD_RATE, (LtU16) lValue );
                break;
            case '6':
                lResult = LeddarSetParameter( LEDDAR_CONFIG_MODBUS_ADDRESS, (LtU16) lValue );
                break;
            case '8':
                lResult = LeddarWriteConfiguration();
                break;
            default:
                lResult = LT_SUCCESS;
                break;
        }

        if ( lResult != LT_SUCCESS )
        {
            puts( "Operation failed!" );
        }
    }
}

// *****************************************************************************
// Function: ConnectMenu
//
/// \brief   Display a menu of actions that can be performed when connected.
// *****************************************************************************

static void
ConnectMenu( void )
{
    char  lBuffer[LT_MAX_PORT_NAME_LEN+1];
    int   lAddress;

    printf( "\nPlease enter the port name: " );
    scanf( "%s", lBuffer );
    printf( "Please enter the MODBUS address: " );
    scanf( "%d", &lAddress );

    if ( LeddarConnect( lBuffer, lAddress ) == LT_SUCCESS )
    {
        for(;;)
        {
            int lChoice;

            puts( "\n\n1. Display detections" );
            puts( "2. Display configuration" );
            puts( "3. Change configuration" );
            puts( "4. Disconnect" );

            lChoice = GetMenuChoice();

            switch( lChoice )
            {
                case '1':
                    DisplayDetections();
                    break;
                case '2':
                    DisplayConfiguration();
                    break;
                case '3':
                    ConfigurationMenu();
                    break;
                case '4':
                    LeddarDisconnect();
                    return;
            }
        }
    }
    else
    {
        puts( "\nConnection failed!" );
    }
}

// *****************************************************************************
// Function: MainMenu
//
/// \brief   Display the main menu (connect or quit).
// *****************************************************************************

static void
MainMenu( void )
{
    for(;;)
    {
        int lChoice;

        puts( "\n\n1. Connect" );
        puts( "2. Quit" );

        lChoice = GetMenuChoice();

        switch( lChoice )
        {
            case '1':
                ConnectMenu();
                break;
            case '2':
            case 'Q':
                return;
        }
    }
}

// *****************************************************************************
// Function: main
//
/// \brief   Standard C entry point!
// *****************************************************************************

int
main( int argc, char *argv[] )
{
    puts( "*******************************************************" );
    puts( "* Welcome to the Leddar Serial Demonstration Program! *" );
    puts( "*******************************************************" );

    MainMenu();

    return 0;
}
